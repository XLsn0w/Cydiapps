#ifndef __LOGOS_H
#define __LOGOS_H
#endif