### iOSOpenDev—iOS Open Development
Copyright (c) 2012-2013 Spencer W.S. James (Kokoabim).

* Follow [@kokoabim](https://twitter.com/kokoabim)
* Download [http://iOSOpenDev.com](http://iOSOpenDev.com)
* Wiki [https://github.com/kokoabim/iOSOpenDev/wiki](https://github.com/kokoabim/iOSOpenDev/wiki/_pages)
* IRC channel #iOSOpenDev on irc.saurik.com
