VERSION = '2.0a1'
default_app_config = 'suit.apps.DjangoSuitConfig'
