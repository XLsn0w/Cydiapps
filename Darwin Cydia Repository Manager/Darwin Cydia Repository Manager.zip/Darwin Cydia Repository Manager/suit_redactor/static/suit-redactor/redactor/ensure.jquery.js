if (!window.jQuery && django && django.jQuery) {
    window.jQuery = window.$ = django.jQuery;
}
