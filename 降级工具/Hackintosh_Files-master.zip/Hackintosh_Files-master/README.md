# Hackintosh_Files
Just have these here to keep track of my hackintosh things.

Feel free to use them if you want but make sure to change the serial numbers, etc. 

No guarantee that they will work for you at all, use at your own discretion.


HP - 250 G5 -
CPU - Intel 5005U -
GPU - Intel HD 5500 -
RAM - 4GB 1600mhz DDR3 -
macOS - 10.14.5

Toshiba - Satellite P50-B -
CPU - Intel 4710HQ -
GPU - Intel HD 4600 -
RAM - 8GB 1600mhz DDR3 -
macOS - 10.13.6

Desktop PC -
CPU - Ryzen 3600 -
GPU - Nvidia GTX 1060 3gb-
RAM - 16GB 3400mhz DDR4 -
macOS - 10.13.6
