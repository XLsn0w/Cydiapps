//
//  download.h
//  tsschecker
//
//  Created by tihmstar on 07.01.16.
//  Copyright © 2016 tihmstar. All rights reserved.
//

#ifndef download_h
#define download_h

#include <stdio.h>

#include "debug.h"

int downloadFile(const char *url, const char *dstPath);

#endif /* download_h */
