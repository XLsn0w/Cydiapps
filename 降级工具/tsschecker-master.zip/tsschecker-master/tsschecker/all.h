//
//  all.h
//  tsschecker
//
//  Created by tihmstar on 26.01.16.
//  Copyright © 2016 tihmstar. All rights reserved.
//

#ifndef all_h
#define all_h

#ifdef DEBUG // this is for developing with Xcode
#define TSSCHECKER_VERSION_COUNT "Debug"
#define TSSCHECKER_VERSION_SHA "Build: " __DATE__ " " __TIME__
#else
#endif

#endif /* all_h */
