//
//  NSString+SHA256.h
//  electra1131
//
//  Created by Pwn20wnd on 7/6/18.
//  Copyright © 2018 Electra Team. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SHA256)

- (NSString *)SHA256String;

@end
