//
//  ViewController.m
//  Osiris12JB
//
//  Created by GeoSn0w on 1/30/19.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *jbYolo;


@end

