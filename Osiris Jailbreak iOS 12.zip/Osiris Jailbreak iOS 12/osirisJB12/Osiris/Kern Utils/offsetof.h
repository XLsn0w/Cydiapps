extern unsigned offsetof_p_pid;
extern unsigned offsetof_task;
extern unsigned offsetof_itk_space;
extern unsigned offsetof_ip_kobject;
extern unsigned offsetof_ipc_space_is_table;

