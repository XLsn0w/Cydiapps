unsigned offsetof_p_pid = 0x60;               // proc_t::p_pid
unsigned offsetof_task = 0x18;                // proc_t::task
unsigned offsetof_itk_space = 0x300;          // task_t::itk_space
unsigned offsetof_ip_kobject = 104;          // ipc_port_t::ip_kobject
unsigned offsetof_ipc_space_is_table = 0x20;  // ipc_space::is_table?..
