# OsirisJailbreak12
iOS 12.0 -> 12.1.2 Incomplete Jailbreak with CVE-2019-6225

An incomplete iOS 12 Jailbreak. For now it only runs the exploit, gets tfp0, gets ROOT, escapes the SandBox, writes a test file to prove the sandbox was escaped then resprings. Feel free to build on top of it as long as you respect the GPLv3 license.

Older (4K) devices are not supported for now. 16K devices are A12 is experimental - may not work..

In order to compile this app, you need to add `qilin.o` to the project. This can be downloaded from http://newosxbook.com/QiLin/qilin.o

### DEVELOPER JAILBREAK! NOT FOR THE GENERAL PUBLIC

### Demo video:
https://twitter.com/FCE365/status/1090770862238777344

### Credits:
<ul>
  <li> Jonathan Levin for QiLin and his books! </li>
  <li> Brandon Azad for the tfp0 exploit </li>  
  <li> Xerub(?) Patchfinder64 </li>
</ul>

### Me:
<ul>
  <li>GeoSn0w on Twitter: <a href="twitter.com/FCE365">@FCE365</a></li>
  <li>My YouTube channel: <a href="youtube.com/fce365official">iDevice Central</li>
</ul>
