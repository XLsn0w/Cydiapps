#ifndef _WX_RCDEFS_H
#define _WX_RCDEFS_H

#define WX_CPU_X86

#endif
