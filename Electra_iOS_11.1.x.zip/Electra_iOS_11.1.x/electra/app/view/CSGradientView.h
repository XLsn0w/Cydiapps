//
//  CSGradientView.h
//  async_wake_ios
//
//  Created by CoolStar on 1/12/18.
//  Copyright © 2018 CoolStar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSGradientView : UIView

@end
