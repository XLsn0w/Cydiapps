//
//  unliberios.h
//  electra
//
//  Created by CoolStar on 2/12/18.
//  Copyright © 2018 Electra Team. All rights reserved.
//

#ifndef unliberios_h
#define unliberios_h

#include <stdbool.h>

bool checkLiberiOS(void);
void removeLiberiOS(void);

#endif /* unliberios_h */
