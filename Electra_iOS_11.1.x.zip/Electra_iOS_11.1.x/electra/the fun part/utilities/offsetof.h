extern unsigned offsetof_p_pid;
extern unsigned offsetof_task;
extern unsigned offsetof_p_ucred;
extern unsigned offsetof_p_csflags;
extern unsigned offsetof_itk_self;
extern unsigned offsetof_itk_sself;
extern unsigned offsetof_itk_bootstrap;
extern unsigned offsetof_ip_mscount;
extern unsigned offsetof_ip_srights;
extern unsigned offsetof_p_textvp;
extern unsigned offsetof_p_textoff;
extern unsigned offsetof_p_cputype;
extern unsigned offsetof_p_cpu_subtype;
extern unsigned offsetof_special;

extern unsigned offsetof_v_type;
extern unsigned offsetof_v_id;
extern unsigned offsetof_v_ubcinfo;
extern unsigned offsetof_v_mount;

extern unsigned offsetof_mnt_flag;

extern unsigned offsetof_ubcinfo_csblobs;

extern unsigned offsetof_csb_cputype;
extern unsigned offsetof_csb_flags;
extern unsigned offsetof_csb_base_offset;
extern unsigned offsetof_csb_entitlements_offset;
extern unsigned offsetof_csb_signer_type;
extern unsigned offsetof_csb_platform_binary;
extern unsigned offsetof_csb_platform_path;
