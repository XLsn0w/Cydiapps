//
//  utils.h
//  electra
//
//  Created by Jamie on 27/01/2018.
//  Copyright © 2018 Electra Team. All rights reserved.
//

#ifndef utils_h
#define utils_h

#include <stdio.h>

int run(const char *cmd);

#endif /* utils_h */
