void unlocknvram(void);
